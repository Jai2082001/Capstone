import image from '../../img/banner.avif'
import classes from './Hero.module.css'
import Container from 'react-bootstrap/esm/Container'
import { useState, useEffect } from 'react'
import { Row, Col, Button } from 'react-bootstrap'
import { Card } from 'react-bootstrap'
import ShelterImg from '../../img/homeless (3).jpg'
import volunteer from '../../img/volunteer.avif';
import Case from '../../img/case.avif';
import Fade from 'react-reveal/Fade'
import ProductDisplayer from '../NewsDisplayer/NewsDisplayer'

const Hero = () => {

    const [blogs, changeBlogs] = useState([]);

    useEffect(()=>{
        fetch(`${process.env.REACT_APP_FETCH_LINK}/randomDisplay`).then((response)=>{
            return response.json();
        }).then((response)=>{
            console.log(response);
            changeBlogs(response);
        })
    }, [])

    return (
        <div className={classes.heroParentDiv}>
            <div className={classes.heroDiv}>
                <img src={image}></img>
            </div>
            <div className={classes.banner}>
                <Container fluid>

                <ProductDisplayer></ProductDisplayer>
                    
                    {/* <Row className={classes.row}>
                        <Col>
                        <Fade>
                            <Card className={classes.card}>
                                <Card.Header as="h5">Shelter Locator</Card.Header>
                                <Card.Img variant="top" src={ShelterImg} />
                                <Card.Body>
                                    <Card.Text>
                                        With supporting text below as a natural lead-in to additional content.
                                    </Card.Text>
                                    <Button variant="primary">Go somewhere</Button>
                                </Card.Body>
                            </Card>
                            </Fade>
                        </Col>
                        <Col>
                        <Fade>
                            <Card className={classes.card}>
                                <Card.Header as="h5">Case Management</Card.Header>
                                <Card.Img variant="top" src={Case} />
                                <Card.Body>
                                    <Card.Text>
                                        With supporting text below as a natural lead-in to additional content.
                                    </Card.Text>
                                    <Button variant="primary">Go somewhere</Button>
                                </Card.Body>
                            </Card>
                        </Fade>
                        </Col>
                        <Col>
                        <Fade>

                            <Card className={classes.card}>
                                <Card.Header as="h5">Volunteer Opportunities</Card.Header>
                                <Card.Img variant="top" src={volunteer} />
                                <Card.Body>
                                    <Card.Text>
                                        With supporting text below as a natural lead-in to additional content.
                                    </Card.Text>
                                    <Button variant="primary">Go somewhere</Button>
                                </Card.Body>
                            </Card>

</Fade>
                        </Col>
                    </Row> */}
                </Container>
            </div>
        </div>
    )
}

export default Hero;