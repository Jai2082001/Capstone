import classes from './AboutUs.module.css'
// import img from './'

const AboutUs = () => {
    return (
        <div className={classes.parentDiv}>
            <h2 className={classes.aboutUsDiv}>About Us</h2>
            <div className={classes.statementDiv}>
                <h2>Duis consectetur ex at nulla ornare egestas. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus</h2>
            </div>
            <div className={classes.aboutUs}>
                <div>
                    {/* <img src={}></img> */}
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque nec dolor enim. Duis consectetur ex at nulla ornare egestas. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nunc nec magna tincidunt, posuere justo eu, facilisis nisl. Sed ultricies urna quis ipsum eleifend venenatis hendrerit quis leo. Nulla sit amet neque ut justo porta fermentum vitae at ante. Maecenas nec augue a lectus sagittis viverra non eu ipsum. Quisque nec cursus turpis. In pulvinar sapien a quam blandit efficitur. Suspendisse tempor erat eu turpis tempor fermentum. Ut blandit odio nibh, in volutpat metus dictum luctus.
                    </p>
                </div>
                <p>
                    Phasellus sit amet sapien finibus, commodo nisi ut, laoreet ipsum. Proin non tellus pharetra, vulputate ligula at, rutrum tellus. Suspendisse quis ullamcorper lacus. Pellentesque aliquam volutpat tincidunt. In vitae eros non velit dictum rutrum vehicula vitae ligula. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse finibus massa mollis dignissim eleifend. Vestibulum tristique orci purus, eu hendrerit lacus suscipit in. Phasellus iaculis aliquam dapibus. Sed quis pharetra nibh. Duis velit lorem, mollis sit amet tortor vitae, venenatis elementum mauris. Pellentesque egestas lectus eget turpis efficitur iaculis. Vivamus consectetur tempor condimentum. Praesent fringilla mauris vel hendrerit tempus.
                </p>
                <p>
                    Donec lacinia nisi quam, ut sodales nisi faucibus vel. Cras varius sodales sem vitae dapibus. Aliquam leo erat, semper vitae purus sed, consequat tempor lorem. Mauris metus tellus, ultrices et mauris eu, volutpat auctor odio. In congue, lacus at facilisis tempor, enim eros efficitur est, non lobortis dolor nibh varius ante. Vivamus dictum felis vitae turpis ullamcorper mollis. Fusce pretium velit vitae augue dapibus sodales. Fusce nec dolor ut libero tempor tincidunt. Donec eget erat sapien.
                </p>
            </div>
        </div>
    )
}

export default AboutUs;