import classes from './Activity.module.css'
import VolunteerActivity from './VolunteerActivity/VolunteerActivity';

const Activity  = ({item}) => {
   
    return (
        <div className={classes.parentDiv}>
            {
            item.activit == 'shelter' && 
                <div className={classes.parentDiv}> 
                    Arranged a shelter for {item.name} in the {item.nameid}
                </div>
            }
            {item.activity == 'volunteer' && 
                <div>'
                Volunteered in 
                    <VolunteerActivity id = {item.id}></VolunteerActivity>
                </div>
            }
    
        </div>
    )
}

export default Activity;